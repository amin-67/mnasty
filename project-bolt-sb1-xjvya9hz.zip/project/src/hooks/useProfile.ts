import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

interface Profile {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone_number: string;
  parent_phone: string;
  governorate: string;
  grade_level: string;
  balance: number;
  theme_preference: string;
}

export function useProfile() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.user) {
        setProfile(null);
        return;
      }

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', session.user.id)
        .maybeSingle(); // Use maybeSingle instead of single to handle no results gracefully

      if (error) throw error;
      
      if (!data) {
        // If no profile exists, redirect to registration or show an error
        toast.error('الملف الشخصي غير موجود');
        await supabase.auth.signOut();
        return;
      }

      setProfile(data);
    } catch (error) {
      console.error('Error loading profile:', error);
      toast.error('حدث خطأ أثناء تحميل الملف الشخصي');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProfile();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
      loadProfile();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return { profile, loading, reloadProfile: loadProfile };
}