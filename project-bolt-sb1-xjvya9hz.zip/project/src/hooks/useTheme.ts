import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useProfile } from './useProfile';

export function useTheme() {
  const { profile } = useProfile();
  const [theme, setTheme] = useState<'light' | 'dark'>(
    () => (localStorage.getItem('theme') as 'light' | 'dark') || 'light'
  );

  useEffect(() => {
    if (profile?.theme_preference) {
      setTheme(profile.theme_preference as 'light' | 'dark');
    }
  }, [profile?.theme_preference]);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = async () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);

    if (profile?.id) {
      await supabase
        .from('profiles')
        .update({ theme_preference: newTheme })
        .eq('id', profile.id);
    }
  };

  return { theme, toggleTheme };
}