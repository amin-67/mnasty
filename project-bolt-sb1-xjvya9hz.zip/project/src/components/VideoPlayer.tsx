import React, { useEffect, useState, useRef } from 'react';
import {
  MediaPlayer,
  MediaProvider,
  Playlist,
  Track,
  TextTrack,
  MediaFullscreenButton,
  MediaTimeSlider,
  MediaPlayButton,
  MediaMuteButton,
  MediaVolumeSlider,
  MediaTime,
  MediaQualityButton,
  MediaPlaybackRateButton,
} from '@vidstack/react';
import { supabase } from '../lib/supabase';
import { useProfile } from '../hooks/useProfile';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';

interface VideoPlayerProps {
  videoId: string;
  url: string;
  onProgress?: (progress: number) => void;
  onComplete?: () => void;
}

export default function VideoPlayer({ videoId, url, onProgress, onComplete }: VideoPlayerProps) {
  const { profile } = useProfile();
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const playerRef = useRef<any>(null);

  useEffect(() => {
    loadVideoProgress();
  }, [videoId, profile?.id]);

  const loadVideoProgress = async () => {
    if (!profile?.id) return;

    try {
      const { data, error } = await supabase
        .from('video_progress')
        .select('progress_seconds')
        .eq('video_id', videoId)
        .eq('student_id', profile.id)
        .single();

      if (error) throw error;

      if (data?.progress_seconds) {
        setCurrentTime(data.progress_seconds);
        playerRef.current?.seekTo(data.progress_seconds);
      }
    } catch (error) {
      console.error('Error loading video progress:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveProgress = async (seconds: number) => {
    if (!profile?.id) return;

    try {
      const { error } = await supabase
        .from('video_progress')
        .upsert({
          video_id: videoId,
          student_id: profile.id,
          progress_seconds: Math.floor(seconds),
          completed: seconds >= duration * 0.9,
        });

      if (error) throw error;

      if (seconds >= duration * 0.9 && onComplete) {
        onComplete();
      }

      if (onProgress) {
        onProgress(seconds);
      }
    } catch (error) {
      console.error('Error saving video progress:', error);
    }
  };

  const handleTimeUpdate = (event: any) => {
    const currentTime = event.detail;
    setCurrentTime(currentTime);
    saveProgress(currentTime);
  };

  const handleDurationChange = (event: any) => {
    setDuration(event.detail);
  };

  const handleError = (error: any) => {
    setError('حدث خطأ أثناء تحميل الفيديو');
    toast.error('حدث خطأ أثناء تحميل الفيديو');
    console.error('Video error:', error);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-900 rounded-lg">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-900 rounded-lg text-white">
        <p>{error}</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative rounded-lg overflow-hidden shadow-2xl"
    >
      <MediaPlayer
        ref={playerRef}
        src={url}
        onTimeUpdate={handleTimeUpdate}
        onDurationChange={handleDurationChange}
        onError={handleError}
        className="aspect-video w-full bg-gray-900"
      >
        <MediaProvider>
          <Track src={url} />
        </MediaProvider>
        
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <MediaPlayButton className="text-white hover:text-indigo-400 transition-colors" />
              <MediaMuteButton className="text-white hover:text-indigo-400 transition-colors" />
              <MediaVolumeSlider className="w-20" />
              <MediaTime className="text-white" />
              <div className="flex-grow">
                <MediaTimeSlider className="w-full" />
              </div>
              <MediaQualityButton className="text-white hover:text-indigo-400 transition-colors" />
              <MediaPlaybackRateButton className="text-white hover:text-indigo-400 transition-colors" />
              <MediaFullscreenButton className="text-white hover:text-indigo-400 transition-colors" />
            </div>
          </div>
        </div>
      </MediaPlayer>

      {/* Progress Indicator */}
      <div className="mt-4">
        <div className="flex justify-between text-sm text-gray-500 mb-1">
          <span>التقدم</span>
          <span>{Math.round((currentTime / duration) * 100)}%</span>
        </div>
        <div className="h-1 bg-gray-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-indigo-500 transition-all duration-300"
            style={{ width: `${(currentTime / duration) * 100}%` }}
          />
        </div>
      </div>
    </motion.div>
  );
}