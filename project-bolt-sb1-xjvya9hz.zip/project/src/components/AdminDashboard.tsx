import React, { useState, useEffect } from 'react';
import { Plus, Trash, Edit, DollarSign, Video, Users, Award, Clock, Activity, Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import { format } from 'date-fns';
import { arEG } from 'date-fns/locale';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, BarChart, Bar } from 'recharts';

interface PaymentCode {
  id: string;
  code: string;
  amount: number;
  used_at: string | null;
  used_by: string | null;
}

interface AdminStats {
  totalUsers: number;
  totalVideos: number;
  totalRevenue: number;
  activeUsers: number;
  dailyLogins: { date: string; count: number }[];
  revenueByDay: { date: string; amount: number }[];
  usersByGovernorate: { governorate: string; count: number }[];
  topVideos: { title: string; views: number }[];
  quizStats: {
    totalAttempts: number;
    averageScore: number;
    completionRate: number;
  };
}

interface UserActivity {
  id: string;
  first_name: string;
  last_name: string;
  last_login: string;
  videos_watched: number;
  quizzes_completed: number;
}

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [paymentCodes, setPaymentCodes] = useState<PaymentCode[]>([]);
  const [newCodeAmount, setNewCodeAmount] = useState('');
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 0,
    totalVideos: 0,
    totalRevenue: 0,
    activeUsers: 0,
    dailyLogins: [],
    revenueByDay: [],
    usersByGovernorate: [],
    topVideos: [],
    quizStats: {
      totalAttempts: 0,
      averageScore: 0,
      completionRate: 0,
    },
  });
  const [userActivities, setUserActivities] = useState<UserActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('week'); // 'week', 'month', 'year'

  useEffect(() => {
    loadStats();
    loadPaymentCodes();
    loadUserActivities();
  }, [dateRange]);

  const loadStats = async () => {
    try {
      // Basic stats
      const { count: usersCount } = await supabase
        .from('profiles')
        .select('*', { count: 'exact' });

      const { count: videosCount } = await supabase
        .from('videos')
        .select('*', { count: 'exact' });

      // Revenue stats
      const { data: transactions } = await supabase
        .from('wallet_transactions')
        .select('amount, created_at')
        .order('created_at', { ascending: true });

      // Active users (last 7 days)
      const { count: activeCount } = await supabase
        .from('profiles')
        .select('*', { count: 'exact' })
        .gte('updated_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString());

      // Daily logins
      const { data: loginData } = await supabase
        .from('profiles')
        .select('updated_at')
        .gte('updated_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString());

      // Users by governorate
      const { data: governorateData } = await supabase
        .from('profiles')
        .select('governorate');

      // Top videos
      const { data: videoProgress } = await supabase
        .from('video_progress')
        .select('video_id, videos(title)')
        .not('completed', 'is', null);

      // Quiz statistics
      const { data: quizAttempts } = await supabase
        .from('quiz_attempts')
        .select('*');

      // Process and aggregate data
      const dailyLogins = processDailyLogins(loginData || []);
      const revenueByDay = processRevenueByDay(transactions || []);
      const usersByGovernorate = processUsersByGovernorate(governorateData || []);
      const topVideos = processTopVideos(videoProgress || []);
      const quizStats = processQuizStats(quizAttempts || []);

      setStats({
        totalUsers: usersCount || 0,
        totalVideos: videosCount || 0,
        totalRevenue: transactions?.reduce((sum, t) => sum + (t.amount || 0), 0) || 0,
        activeUsers: activeCount || 0,
        dailyLogins,
        revenueByDay,
        usersByGovernorate,
        topVideos,
        quizStats,
      });
    } catch (error) {
      console.error('Error loading stats:', error);
      toast.error('حدث خطأ أثناء تحميل الإحصائيات');
    }
  };

  const loadUserActivities = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select(`
          id,
          first_name,
          last_name,
          updated_at,
          video_progress(count),
          quiz_attempts(count)
        `)
        .order('updated_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      const activities = data.map(user => ({
        id: user.id,
        first_name: user.first_name,
        last_name: user.last_name,
        last_login: user.updated_at,
        videos_watched: user.video_progress?.length || 0,
        quizzes_completed: user.quiz_attempts?.length || 0,
      }));

      setUserActivities(activities);
    } catch (error) {
      console.error('Error loading user activities:', error);
      toast.error('حدث خطأ أثناء تحميل نشاطات المستخدمين');
    }
  };

  const loadPaymentCodes = async () => {
    try {
      const { data, error } = await supabase
        .from('payment_codes')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPaymentCodes(data || []);
    } catch (error) {
      console.error('Error loading payment codes:', error);
      toast.error('حدث خطأ أثناء تحميل أكواد الدفع');
    } finally {
      setLoading(false);
    }
  };

  const generatePaymentCode = async () => {
    if (!newCodeAmount) return;

    try {
      const amount = parseFloat(newCodeAmount);
      const code = Math.random().toString(36).substring(2, 8).toUpperCase();

      const { error } = await supabase
        .from('payment_codes')
        .insert([{ code, amount }]);

      if (error) throw error;

      toast.success('تم إنشاء كود الدفع بنجاح');
      loadPaymentCodes();
      setNewCodeAmount('');
    } catch (error) {
      console.error('Error generating payment code:', error);
      toast.error('حدث خطأ أثناء إنشاء كود الدفع');
    }
  };

  const deactivateCode = async (id: string) => {
    try {
      const { error } = await supabase
        .from('payment_codes')
        .update({ is_active: false })
        .eq('id', id);

      if (error) throw error;

      toast.success('تم إلغاء تفعيل الكود بنجاح');
      loadPaymentCodes();
    } catch (error) {
      console.error('Error deactivating code:', error);
      toast.error('حدث خطأ أثناء إلغاء تفعيل الكود');
    }
  };

  // Helper functions for data processing
  const processDailyLogins = (data: any[]) => {
    const days = new Map();
    data.forEach(login => {
      const date = format(new Date(login.updated_at), 'yyyy-MM-dd');
      days.set(date, (days.get(date) || 0) + 1);
    });
    return Array.from(days, ([date, count]) => ({ date, count }));
  };

  const processRevenueByDay = (data: any[]) => {
    const days = new Map();
    data.forEach(transaction => {
      const date = format(new Date(transaction.created_at), 'yyyy-MM-dd');
      days.set(date, (days.get(date) || 0) + transaction.amount);
    });
    return Array.from(days, ([date, amount]) => ({ date, amount }));
  };

  const processUsersByGovernorate = (data: any[]) => {
    const govs = new Map();
    data.forEach(user => {
      govs.set(user.governorate, (govs.get(user.governorate) || 0) + 1);
    });
    return Array.from(govs, ([governorate, count]) => ({ governorate, count }));
  };

  const processTopVideos = (data: any[]) => {
    const videos = new Map();
    data.forEach(progress => {
      const title = progress.videos?.title;
      if (title) {
        videos.set(title, (videos.get(title) || 0) + 1);
      }
    });
    return Array.from(videos, ([title, views]) => ({ title, views }))
      .sort((a, b) => b.views - a.views)
      .slice(0, 5);
  };

  const processQuizStats = (attempts: any[]) => {
    const totalAttempts = attempts.length;
    const completedAttempts = attempts.filter(a => a.completed_at).length;
    const totalScore = attempts.reduce((sum, a) => sum + (a.score || 0), 0);

    return {
      totalAttempts,
      averageScore: totalAttempts ? totalScore / totalAttempts : 0,
      completionRate: totalAttempts ? (completedAttempts / totalAttempts) * 100 : 0,
    };
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">إجمالي الطلاب</p>
              <h3 className="text-2xl font-bold">{stats.totalUsers}</h3>
            </div>
            <Users className="w-8 h-8 text-indigo-600" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">الفيديوهات</p>
              <h3 className="text-2xl font-bold">{stats.totalVideos}</h3>
            </div>
            <Video className="w-8 h-8 text-indigo-600" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">الإيرادات</p>
              <h3 className="text-2xl font-bold">{stats.totalRevenue} جنيه</h3>
            </div>
            <DollarSign className="w-8 h-8 text-indigo-600" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">المستخدمين النشطين</p>
              <h3 className="text-2xl font-bold">{stats.activeUsers}</h3>
            </div>
            <Activity className="w-8 h-8 text-indigo-600" />
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">تسجيلات الدخول اليومية</h3>
          <LineChart width={500} height={300} data={stats.dailyLogins}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="count" stroke="#4F46E5" />
          </LineChart>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">الإيرادات اليومية</h3>
          <BarChart width={500} height={300} data={stats.revenueByDay}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="amount" fill="#4F46E5" />
          </BarChart>
        </div>
      </div>

      {/* User Activity Table */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold mb-4">نشاط المستخدمين</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الاسم
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  آخر دخول
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الفيديوهات المشاهدة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الاختبارات المكتملة
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {userActivities.map((user) => (
                <tr key={user.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {user.first_name} {user.last_name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {format(new Date(user.last_login), 'PPP', { locale: arEG })}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {user.videos_watched}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {user.quizzes_completed}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Codes Management */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold mb-4">إدارة أكواد الدفع</h3>
        
        <div className="flex gap-4 mb-6">
          <input
            type="number"
            placeholder="قيمة الكود"
            className="flex-1 rounded-md border-gray-300"
            value={newCodeAmount}
            onChange={(e) => setNewCodeAmount(e.target.value)}
          />
          <button
            onClick={generatePaymentCode}
            className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
          >
            <Plus className="w-5 h-5" />
            إنشاء كود جديد
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الكود
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  القيمة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الحالة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  تاريخ الاستخدام
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  إجراءات
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {paymentCodes.map((code) => (
                <tr key={code.id}>
                  <td className="px-6 py-4 whitespace-nowrap">{code.code}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{code.amount} جنيه</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {code.used_at ? (
                      <span className="text-red-600">مستخدم</span>
                    ) : (
                      <span className="text-green-600">متاح</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {code.used_at ? format(new Date(code.used_at), 'PPP', { locale: arEG }) : '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {!code.used_at && (
                      <button
                        onClick={() => deactivateCode(code.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <Trash className="w-5 h-5" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}