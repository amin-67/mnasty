import React, { useEffect, useState } from 'react';
import { CheckCircle, Clock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useProfile } from '../hooks/useProfile';

interface Progress {
  quizzes: {
    total: number;
    completed: number;
    averageScore: number;
  };
  videos: {
    total: number;
    completed: number;
    inProgress: number;
  };
  attendance: {
    total: number;
    present: number;
  };
}

export default function ProgressTracker() {
  const { profile } = useProfile();
  const [progress, setProgress] = useState<Progress>({
    quizzes: { total: 0, completed: 0, averageScore: 0 },
    videos: { total: 0, completed: 0, inProgress: 0 },
    attendance: { total: 0, present: 0 },
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile?.id) {
      loadProgress();
    }
  }, [profile?.id]);

  const loadProgress = async () => {
    if (!profile?.id) return;

    try {
      // Load quiz progress
      const { data: quizAttempts } = await supabase
        .from('quiz_attempts')
        .select('*')
        .eq('student_id', profile.id);

      const { data: totalQuizzes } = await supabase
        .from('quizzes')
        .select('id', { count: 'exact' });

      // Load video progress
      const { data: videoProgress } = await supabase
        .from('video_progress')
        .select('*')
        .eq('student_id', profile.id);

      const { data: totalVideos } = await supabase
        .from('videos')
        .select('id', { count: 'exact' });

      // Load attendance
      const { data: attendance } = await supabase
        .from('attendance')
        .select('*')
        .eq('student_id', profile.id);

      const { data: totalClasses } = await supabase
        .from('courses')
        .select('id', { count: 'exact' });

      // Calculate progress
      const completedQuizzes = quizAttempts?.filter(a => a.completed_at) || [];
      const averageScore = completedQuizzes.reduce((acc, curr) => acc + (curr.score || 0), 0) / 
        (completedQuizzes.length || 1);

      const completedVideos = videoProgress?.filter(v => v.completed) || [];
      const inProgressVideos = videoProgress?.filter(v => !v.completed && v.progress_seconds > 0) || [];

      setProgress({
        quizzes: {
          total: totalQuizzes?.length || 0,
          completed: completedQuizzes.length,
          averageScore,
        },
        videos: {
          total: totalVideos?.length || 0,
          completed: completedVideos.length,
          inProgress: inProgressVideos.length,
        },
        attendance: {
          total: totalClasses?.length || 0,
          present: attendance?.length || 0,
        },
      });
    } catch (error) {
      console.error('Error loading progress:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-center py-8">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">تقدمك</h2>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-4">الاختبارات</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>عدد الاختبارات</span>
              <span>{progress.quizzes.total}</span>
            </div>
            <div className="flex justify-between">
              <span>تم إكمال</span>
              <span>{progress.quizzes.completed}</span>
            </div>
            <div className="flex justify-between">
              <span>متوسط الدرجات</span>
              <span>{progress.quizzes.averageScore.toFixed(1)}%</span>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-4">الفيديوهات</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>عدد الفيديوهات</span>
              <span>{progress.videos.total}</span>
            </div>
            <div className="flex justify-between">
              <span>تم مشاهدة</span>
              <span>{progress.videos.completed}</span>
            </div>
            <div className="flex justify-between">
              <span>قيد المشاهدة</span>
              <span>{progress.videos.inProgress}</span>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-4">الحضور</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>عدد المحاضرات</span>
              <span>{progress.attendance.total}</span>
            </div>
            <div className="flex justify-between">
              <span>تم حضور</span>
              <span>{progress.attendance.present}</span>
            </div>
            <div className="flex justify-between">
              <span>نسبة الحضور</span>
              <span>
                {progress.attendance.total > 0
                  ? ((progress.attendance.present / progress.attendance.total) * 100).toFixed(1)
                  : 0}%
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold mb-4">آخر النشاطات</h3>
        {/* Activity feed will be implemented here */}
      </div>
    </div>
  );
}