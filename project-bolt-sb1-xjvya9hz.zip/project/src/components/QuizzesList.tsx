import React, { useEffect, useState } from 'react';
import { Clock, CheckCircle, Plus, Edit, Trash, AlertTriangle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useProfile } from '../hooks/useProfile';
import toast from 'react-hot-toast';

interface Quiz {
  id: string;
  title: string;
  description: string;
  time_limit: number;
  course_id: string;
  questions: Question[];
}

interface Question {
  id: string;
  text: string;
  options: string[];
  correct_answer: number;
}

interface QuizAttempt {
  id: string;
  score: number;
  completed_at: string;
}

export default function QuizzesList() {
  const { profile } = useProfile();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [attempts, setAttempts] = useState<Record<string, QuizAttempt>>({});
  const [loading, setLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  const [newQuiz, setNewQuiz] = useState<{
    title: string;
    description: string;
    time_limit: number;
    questions: Question[];
  }>({
    title: '',
    description: '',
    time_limit: 30,
    questions: [],
  });

  useEffect(() => {
    loadQuizzes();
    if (profile?.id) {
      loadAttempts();
    }
  }, [profile?.id]);

  const loadQuizzes = async () => {
    try {
      const { data, error } = await supabase
        .from('quizzes')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setQuizzes(data || []);
    } catch (error) {
      console.error('Error loading quizzes:', error);
      toast.error('حدث خطأ أثناء تحميل الاختبارات');
    } finally {
      setLoading(false);
    }
  };

  const loadAttempts = async () => {
    if (!profile?.id) return;

    try {
      const { data, error } = await supabase
        .from('quiz_attempts')
        .select('*')
        .eq('student_id', profile.id);

      if (error) throw error;

      const attemptsMap = (data || []).reduce((acc, attempt) => {
        acc[attempt.quiz_id] = attempt;
        return acc;
      }, {} as Record<string, QuizAttempt>);

      setAttempts(attemptsMap);
    } catch (error) {
      console.error('Error loading attempts:', error);
    }
  };

  const addQuestion = () => {
    setNewQuiz(prev => ({
      ...prev,
      questions: [
        ...prev.questions,
        {
          id: Math.random().toString(36).substr(2, 9),
          text: '',
          options: ['', '', '', ''],
          correct_answer: 0,
        },
      ],
    }));
  };

  const updateQuestion = (index: number, field: keyof Question, value: any) => {
    setNewQuiz(prev => {
      const questions = [...prev.questions];
      questions[index] = { ...questions[index], [field]: value };
      return { ...prev, questions };
    });
  };

  const removeQuestion = (index: number) => {
    setNewQuiz(prev => ({
      ...prev,
      questions: prev.questions.filter((_, i) => i !== index),
    }));
  };

  const createQuiz = async () => {
    if (!profile?.id) return;

    try {
      const { error } = await supabase.from('quizzes').insert([
        {
          ...newQuiz,
          created_by: profile.id,
        },
      ]);

      if (error) throw error;

      toast.success('تم إنشاء الاختبار بنجاح');
      setIsCreating(false);
      setNewQuiz({
        title: '',
        description: '',
        time_limit: 30,
        questions: [],
      });
      loadQuizzes();
    } catch (error) {
      console.error('Error creating quiz:', error);
      toast.error('حدث خطأ أثناء إنشاء الاختبار');
    }
  };

  const startQuiz = async (quizId: string) => {
    if (!profile?.id) return;

    try {
      const { data, error } = await supabase
        .from('quiz_attempts')
        .insert([
          {
            quiz_id: quizId,
            student_id: profile.id,
          },
        ])
        .select()
        .single();

      if (error) throw error;

      window.location.href = `/quiz/${quizId}/attempt/${data.id}`;
    } catch (error) {
      console.error('Error starting quiz:', error);
      toast.error('حدث خطأ أثناء بدء الاختبار');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">الاختبارات المتاحة</h2>
        {profile?.role === 'admin' && (
          <button
            onClick={() => setIsCreating(true)}
            className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
          >
            <Plus className="w-5 h-5 mr-2" />
            إنشاء اختبار جديد
          </button>
        )}
      </div>

      {isCreating && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <h3 className="text-xl font-semibold mb-4">إنشاء اختبار جديد</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">عنوان الاختبار</label>
              <input
                type="text"
                value={newQuiz.title}
                onChange={(e) => setNewQuiz({ ...newQuiz, title: e.target.value })}
                className="w-full rounded-md border-gray-300"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">الوصف</label>
              <textarea
                value={newQuiz.description}
                onChange={(e) => setNewQuiz({ ...newQuiz, description: e.target.value })}
                className="w-full rounded-md border-gray-300"
                rows={3}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">المدة (بالدقائق)</label>
              <input
                type="number"
                value={newQuiz.time_limit}
                onChange={(e) => setNewQuiz({ ...newQuiz, time_limit: parseInt(e.target.value) })}
                className="w-full rounded-md border-gray-300"
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-lg font-medium">الأسئلة</h4>
                <button
                  onClick={addQuestion}
                  className="flex items-center px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  إضافة سؤال
                </button>
              </div>

              {newQuiz.questions.map((question, qIndex) => (
                <div key={question.id} className="border rounded-md p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <label className="block text-sm font-medium mb-1">نص السؤال</label>
                      <input
                        type="text"
                        value={question.text}
                        onChange={(e) => updateQuestion(qIndex, 'text', e.target.value)}
                        className="w-full rounded-md border-gray-300"
                      />
                    </div>
                    <button
                      onClick={() => removeQuestion(qIndex)}
                      className="ml-2 text-red-600 hover:text-red-800"
                    >
                      <Trash className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="space-y-2">
                    {question.options.map((option, oIndex) => (
                      <div key={oIndex} className="flex items-center space-x-2">
                        <input
                          type="radio"
                          name={`correct-${question.id}`}
                          checked={question.correct_answer === oIndex}
                          onChange={() => updateQuestion(qIndex, 'correct_answer', oIndex)}
                          className="ml-2"
                        />
                        <input
                          type="text"
                          value={option}
                          onChange={(e) => {
                            const newOptions = [...question.options];
                            newOptions[oIndex] = e.target.value;
                            updateQuestion(qIndex, 'options', newOptions);
                          }}
                          className="flex-1 rounded-md border-gray-300"
                          placeholder={`الخيار ${oIndex + 1}`}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end space-x-2">
              <button
                onClick={() => setIsCreating(false)}
                className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={createQuiz}
                disabled={!newQuiz.title || newQuiz.questions.length === 0}
                className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors disabled:opacity-50"
              >
                إنشاء الاختبار
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {quizzes.map((quiz) => {
          const attempt = attempts[quiz.id];
          const hasQuestions = quiz.questions && quiz.questions.length > 0;
          
          return (
            <div
              key={quiz.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden transform hover:scale-[1.02] transition-transform"
            >
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{quiz.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-2">
                  {quiz.description}
                </p>
                
                <div className="flex items-center text-gray-500 dark:text-gray-400 mb-4">
                  <Clock className="w-4 h-4 mr-2" />
                  <span>{quiz.time_limit} دقيقة</span>
                </div>

                {!hasQuestions && (
                  <div className="flex items-center text-amber-600 mb-4">
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    <span>لا توجد أسئلة بعد</span>
                  </div>
                )}

                {attempt?.completed_at ? (
                  <div className="space-y-4">
                    <div className="flex items-center text-green-600 dark:text-green-400">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      <span>الدرجة: {attempt.score}%</span>
                    </div>
                    <button
                      onClick={() => startQuiz(quiz.id)}
                      disabled={!hasQuestions}
                      className="w-full px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      إعادة المحاولة
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => startQuiz(quiz.id)}
                    disabled={!hasQuestions}
                    className="w-full px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    بدء الاختبار
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}