import React, { useEffect, useState } from 'react';
import { Play, Upload, CheckCircle, Edit, Trash, AlertTriangle, DollarSign } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useProfile } from '../hooks/useProfile';
import toast from 'react-hot-toast';

interface Video {
  id: string;
  title: string;
  description: string;
  url: string;
  course_id: string;
  is_paid: boolean;
  price: number;
}

interface VideoProgress {
  video_id: string;
  progress_seconds: number;
  completed: boolean;
}

export default function VideosList() {
  const { profile } = useProfile();
  const [videos, setVideos] = useState<Video[]>([]);
  const [progress, setProgress] = useState<Record<string, VideoProgress>>({});
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [editingVideo, setEditingVideo] = useState<Video | null>(null);
  const [newVideo, setNewVideo] = useState({
    title: '',
    description: '',
    price: 0,
    is_paid: false,
  });

  useEffect(() => {
    loadVideos();
    if (profile?.id) {
      loadProgress();
    }
  }, [profile?.id]);

  const loadVideos = async () => {
    try {
      const { data, error } = await supabase
        .from('videos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setVideos(data || []);
    } catch (error) {
      console.error('Error loading videos:', error);
      toast.error('حدث خطأ أثناء تحميل الفيديوهات');
    } finally {
      setLoading(false);
    }
  };

  const loadProgress = async () => {
    try {
      const { data, error } = await supabase
        .from('video_progress')
        .select('*')
        .eq('student_id', profile.id);

      if (error) throw error;

      const progressMap = (data || []).reduce((acc, prog) => {
        acc[prog.video_id] = prog;
        return acc;
      }, {} as Record<string, VideoProgress>);

      setProgress(progressMap);
    } catch (error) {
      console.error('Error loading progress:', error);
    }
  };

  const handleUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files || !event.target.files[0]) return;

    const file = event.target.files[0];
    setUploading(true);

    try {
      const fileExt = file.name.split('.').pop();
      const filePath = `${Math.random()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('videos')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('videos')
        .getPublicUrl(filePath);

      const { error: dbError } = await supabase
        .from('videos')
        .insert([
          {
            title: newVideo.title || file.name.split('.')[0],
            description: newVideo.description || 'تم الرفع بواسطة المدرس',
            url: publicUrl,
            is_paid: newVideo.is_paid,
            price: newVideo.price,
          }
        ]);

      if (dbError) throw dbError;

      toast.success('تم رفع الفيديو بنجاح');
      setNewVideo({
        title: '',
        description: '',
        price: 0,
        is_paid: false,
      });
      loadVideos();
    } catch (error) {
      console.error('Error uploading video:', error);
      toast.error('حدث خطأ أثناء رفع الفيديو');
    } finally {
      setUploading(false);
    }
  };

  const updateVideo = async (videoId: string) => {
    if (!editingVideo) return;

    try {
      const { error } = await supabase
        .from('videos')
        .update({
          title: editingVideo.title,
          description: editingVideo.description,
          is_paid: editingVideo.is_paid,
          price: editingVideo.price,
        })
        .eq('id', videoId);

      if (error) throw error;

      toast.success('تم تحديث الفيديو بنجاح');
      setEditingVideo(null);
      loadVideos();
    } catch (error) {
      console.error('Error updating video:', error);
      toast.error('حدث خطأ أثناء تحديث الفيديو');
    }
  };

  const deleteVideo = async (videoId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الفيديو؟')) return;

    try {
      const { error } = await supabase
        .from('videos')
        .delete()
        .eq('id', videoId);

      if (error) throw error;

      toast.success('تم حذف الفيديو بنجاح');
      loadVideos();
    } catch (error) {
      console.error('Error deleting video:', error);
      toast.error('حدث خطأ أثناء حذف الفيديو');
    }
  };

  const purchaseVideo = async (videoId: string, price: number) => {
    if (!profile?.id) return;

    try {
      const { error: purchaseError } = await supabase
        .from('video_purchases')
        .insert([
          {
            video_id: videoId,
            user_id: profile.id,
            amount_paid: price,
          }
        ]);

      if (purchaseError) throw purchaseError;

      const { error: balanceError } = await supabase
        .from('profiles')
        .update({ balance: profile.balance - price })
        .eq('id', profile.id);

      if (balanceError) throw balanceError;

      toast.success('تم شراء الفيديو بنجاح');
      loadVideos();
    } catch (error) {
      console.error('Error purchasing video:', error);
      toast.error('حدث خطأ أثناء شراء الفيديو');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">الفيديوهات المتاحة</h2>
        
        {profile?.role === 'admin' && (
          <div className="flex gap-4">
            <div className="space-y-2">
              <input
                type="text"
                placeholder="عنوان الفيديو"
                className="block w-full rounded-md border-gray-300"
                value={newVideo.title}
                onChange={(e) => setNewVideo({ ...newVideo, title: e.target.value })}
              />
              <textarea
                placeholder="وصف الفيديو"
                className="block w-full rounded-md border-gray-300"
                value={newVideo.description}
                onChange={(e) => setNewVideo({ ...newVideo, description: e.target.value })}
              />
              <div className="flex gap-2">
                <input
                  type="number"
                  placeholder="السعر"
                  className="block w-full rounded-md border-gray-300"
                  value={newVideo.price}
                  onChange={(e) => setNewVideo({ ...newVideo, price: parseFloat(e.target.value) })}
                />
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={newVideo.is_paid}
                    onChange={(e) => setNewVideo({ ...newVideo, is_paid: e.target.checked })}
                    className="ml-2"
                  />
                  مدفوع
                </label>
              </div>
            </div>
            <label className="cursor-pointer bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors h-fit">
              <input
                type="file"
                accept="video/*"
                className="hidden"
                onChange={handleUpload}
                disabled={uploading}
              />
              <Upload className="inline-block w-4 h-4 mr-2" />
              {uploading ? 'جاري الرفع...' : 'رفع فيديو جديد'}
            </label>
          </div>
        )}
      </div>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {videos.map((video) => {
          const videoProgress = progress[video.id];
          
          return (
            <div
              key={video.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden transform hover:scale-[1.02] transition-transform"
            >
              <div className="aspect-video bg-gray-100 dark:bg-gray-700 relative group">
                <video src={video.url} className="w-full h-full object-cover" />
                <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Play className="w-12 h-12 text-white" />
                </div>
                {video.is_paid && (
                  <div className="absolute top-2 right-2 bg-amber-500 text-white px-2 py-1 rounded-full text-sm flex items-center">
                    <DollarSign className="w-4 h-4 mr-1" />
                    {video.price} جن
                  </div>
                )}
              </div>
              
              <div className="p-6">
                {editingVideo?.id === video.id ? (
                  <div className="space-y-4">
                    <input
                      type="text"
                      value={editingVideo.title}
                      onChange={(e) => setEditingVideo({ ...editingVideo, title: e.target.value })}
                      className="w-full rounded-md border-gray-300"
                    />
                    <textarea
                      value={editingVideo.description}
                      onChange={(e) => setEditingVideo({ ...editingVideo, description: e.target.value })}
                      className="w-full rounded-md border-gray-300"
                      rows={3}
                    />
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={editingVideo.price}
                        onChange={(e) => setEditingVideo({ ...editingVideo, price: parseFloat(e.target.value) })}
                        className="w-full rounded-md border-gray-300"
                      />
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={editingVideo.is_paid}
                          onChange={(e) => setEditingVideo({ ...editingVideo, is_paid: e.target.checked })}
                          className="ml-2"
                        />
                        مدفوع
                      </label>
                    </div>
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => setEditingVideo(null)}
                        className="px-3 py-1 text-gray-600 hover:text-gray-800"
                      >
                        إلغاء
                      </button>
                      <button
                        onClick={() => updateVideo(video.id)}
                        className="px-3 py-1 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                      >
                        حفظ
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <h3 className="text-xl font-semibold mb-2">{video.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-2">
                      {video.description}
                    </p>
                  </>
                )}

                {profile?.role === 'admin' && !editingVideo && (
                  <div className="flex justify-end gap-2 mb-4">
                    <button
                      onClick={() => setEditingVideo(video)}
                      className="text-indigo-600 hover:text-indigo-800"
                    >
                      <Edit className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => deleteVideo(video.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash className="w-5 h-5" />
                    </button>
                  </div>
                )}
                
                {videoProgress?.completed ? (
                  <div className="flex items-center text-green-600 dark:text-green-400">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    <span>تم المشاهدة</span>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {video.is_paid && (
                      <button
                        onClick={() => purchaseVideo(video.id, video.price)}
                        className="w-full px-4 py-2 bg-amber-500 text-white rounded-md hover:bg-amber-600 transition-colors"
                      >
                        شراء الفيديو
                      </button>
                    )}
                    <div className="relative pt-1">
                      <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                        <div
                          style={{
                            width: `${(videoProgress?.progress_seconds || 0) / 100}%`
                          }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-indigo-500"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}