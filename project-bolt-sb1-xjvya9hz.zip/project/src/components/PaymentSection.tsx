import React, { useState } from 'react';
import { Phone, MessageSquare } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useProfile } from '../hooks/useProfile';
import toast from 'react-hot-toast';

export default function PaymentSection() {
  const { profile, reloadProfile } = useProfile();
  const [paymentCode, setPaymentCode] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRedeemCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile?.id || !paymentCode) return;

    setLoading(true);
    try {
      const { data: payment, error: paymentError } = await supabase
        .from('payments')
        .select('*')
        .eq('payment_code', paymentCode)
        .eq('used', false)
        .single();

      if (paymentError || !payment) {
        toast.error('كود غير صالح أو تم استخدامه من قبل');
        return;
      }

      const { error: updateError } = await supabase
        .from('payments')
        .update({ used: true })
        .eq('id', payment.id);

      if (updateError) throw updateError;

      const { error: transactionError } = await supabase
        .from('wallet_transactions')
        .insert([
          {
            student_id: profile.id,
            amount: payment.amount,
            transaction_type: 'deposit',
            description: 'إيداع عن طريق كود دفع'
          }
        ]);

      if (transactionError) throw transactionError;

      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          balance: (profile.balance || 0) + payment.amount
        })
        .eq('id', profile.id);

      if (profileError) throw profileError;

      toast.success('تم إضافة الرصيد بنجاح');
      reloadProfile();
      setPaymentCode('');
    } catch (error) {
      console.error('Error redeeming code:', error);
      toast.error('حدث خطأ أثناء إضافة الرصيد');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-6">إضافة رصيد</h2>
        
        <div className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">للدفع:</h3>
            <div className="flex items-center space-x-4">
              <Phone className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              <span className="text-gray-600 dark:text-gray-300">01288708674</span>
            </div>
            <div className="flex items-center space-x-4">
              <MessageSquare className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              <a
                href="https://t.me/EE_LLP"
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-600 hover:text-indigo-500"
              >
                تواصل عبر تليجرام
              </a>
            </div>
            <div className="flex items-center space-x-4">
              <MessageSquare className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              <a
                href="https://wa.me/+201288708674"
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-600 hover:text-indigo-500"
              >
                تواصل عبر واتساب
              </a>
            </div>
          </div>

          <form onSubmit={handleRedeemCode} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                كود الدفع
              </label>
              <input
                type="text"
                value={paymentCode}
                onChange={(e) => setPaymentCode(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="أدخل كود الدفع"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              {loading ? 'جاري التحقق...' : 'تأكيد الدفع'}
            </button>
          </form>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold mb-4">سجل المعاملات</h3>
        {/* Transaction history will be implemented here */}
      </div>
    </div>
  );
}