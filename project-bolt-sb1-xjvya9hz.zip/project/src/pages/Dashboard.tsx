import React from 'react';
import { useProfile } from '../hooks/useProfile';
import { useTheme } from '../hooks/useTheme';
import { Sun, Moon, LogOut, BookOpen, Video, Award, Users, Calendar, Settings, BarChart } from 'lucide-react';
import { supabase } from '../lib/supabase';
import QuizzesList from '../components/QuizzesList';
import VideosList from '../components/VideosList';
import PaymentSection from '../components/PaymentSection';
import ProgressTracker from '../components/ProgressTracker';
import toast from 'react-hot-toast';

export default function Dashboard() {
  const { profile } = useProfile();
  const { theme, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = React.useState('overview');

  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      toast.success('تم تسجيل الخروج بنجاح');
    } catch (error) {
      console.error('Error logging out:', error);
      toast.error('حدث خطأ أثناء تسجيل الخروج');
    }
  };

  const tabs = [
    { id: 'overview', label: 'نظرة عامة', icon: BarChart },
    { id: 'courses', label: 'المقررات', icon: BookOpen },
    { id: 'videos', label: 'الفيديوهات', icon: Video },
    { id: 'quizzes', label: 'الاختبارات', icon: Award },
    { id: 'community', label: 'مجتمع الطلاب', icon: Users },
    { id: 'schedule', label: 'الجدول الدراسي', icon: Calendar },
    { id: 'settings', label: 'الإعدادات', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">
                الأمين في الأحياء
              </h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-gray-700 dark:text-gray-300">
                الرصيد: {profile?.balance || 0} جنيه
              </div>
              
              <button
                onClick={toggleTheme}
                className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                {theme === 'dark' ? (
                  <Sun className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                ) : (
                  <Moon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                )}
              </button>
              
              <button
                onClick={handleLogout}
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
              >
                <LogOut className="w-5 h-5" />
                <span className="mr-2">تسجيل الخروج</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <div className="w-full md:w-64 space-y-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                >
                  <Icon className="w-5 h-5 ml-3" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Content Area */}
          <div className="flex-1">
            {activeTab === 'overview' && <ProgressTracker />}
            {activeTab === 'videos' && <VideosList />}
            {activeTab === 'quizzes' && <QuizzesList />}
            {activeTab === 'settings' && <PaymentSection />}
          </div>
        </div>
      </main>
    </div>
  );
}