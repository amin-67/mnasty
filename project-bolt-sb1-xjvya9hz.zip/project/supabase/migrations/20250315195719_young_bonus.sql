/*
  # Add Payment and Student Tracking Features

  1. New Tables
    - payments
      - Tracks student payments and wallet balance
      - Stores payment codes and their status
    - video_progress
      - Tracks student video watching progress
      - Records completion status and last watched position
    - attendance
      - Records student attendance and activity
    - wallet_transactions
      - Records all wallet transactions
      - Tracks deposits and purchases

  2. Changes
    - Add balance column to profiles table
    - Add theme preference to profiles
    
  3. Security
    - Enable RLS on new tables
    - Add policies for student access
*/

-- Add balance and theme preference to profiles
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS balance DECIMAL(10,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS theme_preference TEXT DEFAULT 'light';

-- Create payments table
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES profiles(id),
  amount DECIMAL(10,2) NOT NULL,
  payment_code TEXT UNIQUE,
  used BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create video_progress table
CREATE TABLE IF NOT EXISTS video_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES profiles(id),
  video_id UUID REFERENCES videos(id),
  progress_seconds INTEGER DEFAULT 0,
  completed BOOLEAN DEFAULT false,
  last_watched_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create attendance table
CREATE TABLE IF NOT EXISTS attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES profiles(id),
  course_id UUID REFERENCES courses(id),
  attended_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create wallet_transactions table
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES profiles(id),
  amount DECIMAL(10,2) NOT NULL,
  transaction_type TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;

-- Payments policies
CREATE POLICY "Students can view their own payments"
  ON payments FOR SELECT
  TO authenticated
  USING (auth.uid() = student_id);

-- Video progress policies
CREATE POLICY "Students can view and update their video progress"
  ON video_progress FOR ALL
  TO authenticated
  USING (auth.uid() = student_id)
  WITH CHECK (auth.uid() = student_id);

-- Attendance policies
CREATE POLICY "Students can view their own attendance"
  ON attendance FOR SELECT
  TO authenticated
  USING (auth.uid() = student_id);

-- Wallet transactions policies
CREATE POLICY "Students can view their own transactions"
  ON wallet_transactions FOR SELECT
  TO authenticated
  USING (auth.uid() = student_id);