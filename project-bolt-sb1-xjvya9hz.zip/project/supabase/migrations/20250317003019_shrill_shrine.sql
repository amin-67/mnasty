/*
  # Add Admin Controls and Video Monetization

  1. New Tables
    - `admin_users`
      - Links to profiles table
      - Stores admin privileges and roles
    
    - `payment_codes`
      - Stores pre-generated payment codes
      - Tracks code usage and amounts
      
    - `video_purchases`
      - Tracks which users have purchased which videos
      - Links videos to users with purchase timestamps

  2. Changes
    - Add `is_paid` and `price` columns to videos table
    - Add `role` column to profiles table
    
  3. Security
    - Add RLS policies for admin access
    - Add policies for video purchases
*/

-- Add role to profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS role text DEFAULT 'user';

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES profiles(id),
  permissions jsonb DEFAULT '{"videos": true, "quizzes": true, "payments": true}'::jsonb
);

-- Create payment_codes table
CREATE TABLE IF NOT EXISTS payment_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  amount numeric(10,2) NOT NULL,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  used_at timestamptz,
  used_by uuid REFERENCES profiles(id),
  is_active boolean DEFAULT true
);

-- Add monetization columns to videos
ALTER TABLE videos 
  ADD COLUMN IF NOT EXISTS is_paid boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS price numeric(10,2) DEFAULT 0.00;

-- Create video_purchases table
CREATE TABLE IF NOT EXISTS video_purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid REFERENCES videos(id),
  user_id uuid REFERENCES profiles(id),
  amount_paid numeric(10,2) NOT NULL,
  purchased_at timestamptz DEFAULT now(),
  UNIQUE(video_id, user_id)
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_purchases ENABLE ROW LEVEL SECURITY;

-- Admin users policies
CREATE POLICY "Admins can read admin_users"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

CREATE POLICY "Admins can manage admin_users"
  ON admin_users
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Payment codes policies
CREATE POLICY "Admins can manage payment codes"
  ON payment_codes
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

CREATE POLICY "Users can view unused payment codes"
  ON payment_codes
  FOR SELECT
  TO authenticated
  USING (is_active = true AND used_at IS NULL);

-- Video purchases policies
CREATE POLICY "Users can view their own purchases"
  ON video_purchases
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create purchases"
  ON video_purchases
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Update video policies
CREATE POLICY "Users can view purchased videos"
  ON videos
  FOR SELECT
  TO authenticated
  USING (
    NOT is_paid 
    OR EXISTS (
      SELECT 1 FROM video_purchases
      WHERE video_purchases.video_id = id
      AND video_purchases.user_id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );